package modelo;

import java.util.Date;
public interface IProgramable {

    void programable(Date fecha, String hora);
}
